/* eslint-disable no-unused-vars */
/// <reference types="react-scripts" />

// declare namespace NodeJS {
//     interface ProcessEnv {
//         REACT_APP_BASE_URL: string = "";
//     }
// }
// // eslint-disable-next-line no-unused-vars
// interface Window {
//     Stripe: any
// }

// process.env.REACT_APP_BASE_URL = "https://run.mocky.io/v3";
